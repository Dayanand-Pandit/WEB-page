# Dayanand Pandit — AI/ML Engineer & Computer Science Portfolio

Official portfolio website for **Dayanand Pandit** (B.Sc. Computer Science, 2nd Year / 4th Semester — AI/ML Engineer Track).

## Official Links
- **LinkedIn:** [dayanand-pandit-a60911432](https://www.linkedin.com/in/dayanand-pandit-a60911432)
- **X (Twitter):** [@ShitalPandit217](https://x.com/ShitalPandit217)
- **Email:** shitalpandit813@gmail.com

## Security & Authentication
- Admin authentication uses a one-way salted SHA-256 cryptographic digest (`adminAuthHash`). Neither the Admin User ID nor the Admin Password is stored in plaintext anywhere in `index.html` or this repository.
- You can rotate your Admin login hash anytime inside **Admin Studio → Update Admin Credentials**.

## Deploying & Controlling on Your GitHub Account
1. Sign in to your GitHub account and create a new **Public** repository named `<your-github-username>.github.io` (or `portfolio`).
2. Upload `index.html`, `README.md`, `.nojekyll`, and `.github/workflows/deploy.yml` to the `main` branch.
3. In your repository, open **Settings → Pages**, set **Source** to **GitHub Actions** (or **Deploy from a branch → main / root**), and click **Save**.
4. Whenever you upload new skills, projects (`Done`, `Doing`, `Will Do`), portfolio items, or your resume in Admin Mode, click **GitHub & Deploy Control → Download Updated index.html** and replace `index.html` in your GitHub repository to publish your changes globally!
